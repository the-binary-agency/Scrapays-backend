<?php $__env->startComponent('mail::message'); ?>

<?php echo e($body->message); ?>


© Copyright <?php echo e(config('app.name') .' '. now()->year); ?>. All rights reserved.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\scrapays-backend\resources\views/Email/replyContactMessage.blade.php ENDPATH**/ ?>