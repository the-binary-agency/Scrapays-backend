<?php $__env->startComponent('mail::message'); ?>
# Notification

A pickup request has been issued by <span class="font-weight-bold text-capitalize"> <?php echo e($user->first_name. ' ' .$user->last_name); ?>. </span> <br>

<span class="font-weight-bold">Address:</span> <?php echo e($user->address); ?> <br>
<span class="font-weight-bold">Pickup Schedule:</span> <?php echo e($pickup->schedule); ?> <br>
<span class="font-weight-bold">Material Categories:</span>
<ul>
    <?php $__currentLoopData = json_decode($pickup->materials); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($material); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

 <span class="font-weight-bold">Pickup ID:</span> <?php echo e($pickup->id); ?> <br>

<?php $__env->startComponent('mail::button', ['url' => 'https://app.scrapays.com/dashboard/pickup-request/'.$pickup->id]); ?>
View Request
<?php echo $__env->renderComponent(); ?>

<style>
    .font-weight-bold{
        font-weight: bold;
    }
    .text-capitalize{
        text-transform: capitalize;
    }
</style>

© Copyright <?php echo e(config('app.name') .' '. now()->year); ?>. All rights reserved.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\scrapays-backend-V2\resources\views/Email/pickupRequest.blade.php ENDPATH**/ ?>