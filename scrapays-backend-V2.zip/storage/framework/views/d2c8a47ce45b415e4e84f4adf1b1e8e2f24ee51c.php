<?php $__env->startComponent('mail::message'); ?>

<?php echo e($reply->message); ?>


© Copyright <?php echo e(config('app.name') .' '. now()->year); ?>. All rights reserved.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\scrapays-backend-V2\resources\views/Email/replyContactMessage.blade.php ENDPATH**/ ?>