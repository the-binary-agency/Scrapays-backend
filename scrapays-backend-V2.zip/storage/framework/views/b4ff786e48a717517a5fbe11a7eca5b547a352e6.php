<?php $__env->startComponent('mail::message'); ?>
# Password Change Request

A password change was requested on your account with us. <br>
Click on the button below to change your password.

<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:4200/response-password-reset?token='.$token ]); ?>
Reset Password
<?php echo $__env->renderComponent(); ?>

Thanks,<br> 
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\scrapays-backend\resources\views/Email/passwordReset.blade.php ENDPATH**/ ?>