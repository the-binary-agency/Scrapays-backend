<?php $__env->startComponent('mail::message'); ?>
# Successful Registration

Welcome to Scrapays for Household Mr./Mrs. <?php echo e($user->last_name); ?>


We’re thrilled that you’ve decided to join us today and make us your recyclable waste offtake partner.

You can access Scrapays for Household Account Dashboard here:
<a href="https://app.scrapays.com/household/login">https://app.scrapays.com/household/login</a>

Your account login is:
<h3><span class="font-weight-bold">Phone Number:</span> <?php echo e($user->phone); ?> </h3>
<h3><span class="font-weight-bold">Password:</span> <?php echo e($user->password); ?> </h3>


Warm regards, 

Scrapays Team
<a href="www.scrapays.com">www.scrapays.com</a>

Have Question? 
Send a reply this mail and our customer service personnel will be with right away.

<style>
    .font-weight-bold{
        font-weight: bold;
    }
</style>
© Copyright <?php echo e(config('app.name') .' '. now()->year); ?>. All rights reserved.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\scrapays-backend-V2\resources\views/Email/registerHousehold.blade.php ENDPATH**/ ?>