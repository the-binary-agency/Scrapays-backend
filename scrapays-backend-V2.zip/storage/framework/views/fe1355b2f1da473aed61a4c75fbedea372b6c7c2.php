<?php $__env->startComponent('mail::message'); ?>
# Notification

Thanks for requesting for a pickup request; <br>

Be rest assured that you are going to get a follow up call and/or email from our mobile Enterprise Collectors. <br>

Below are the collection details ; <br>
<span class="font-weight-bold"> Name: </span> <span class="text-capitalize"> <?php echo e($user->firstName. ' ' .$user->lastName); ?> </span> <br>
<span class="font-weight-bold">Address:</span> <?php echo e($user->address); ?> <br>
<span class="font-weight-bold">Pickup Schedule:</span> <?php echo e($pickup->schedule); ?> <br>
<span class="font-weight-bold">Material Categories:</span>
<ul>
    <?php $__currentLoopData = json_decode($pickup->materials); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($material); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

 <span class="font-weight-bold">Email:</span> <?php echo e($user->email); ?> <br>
 <span class="font-weight-bold">Pickup ID:</span> <?php echo e($pickup->id); ?> <br>



<style>
    .font-weight-bold{
        font-weight: bold;
    }
     .text-capitalize{
        text-transform: capitalize;
    }
</style>

© Copyright <?php echo e(config('app.name') .' '. now()->year); ?>. All rights reserved.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\scrapays-backend\resources\views/Email/pickupResponse.blade.php ENDPATH**/ ?>