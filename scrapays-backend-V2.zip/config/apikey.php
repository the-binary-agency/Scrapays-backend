<?php
return [
    'apikey' => env('API_KEY'),

    'google' => env('GOOGLE_MAPS_API_KEY')
];
