<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LocationData extends Model
{
    //
}
