<?php

namespace App\Http\Controllers;

use App\collectedScrap;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Str;

class CollectedScrapController extends Controller
{
    public function listCollectedScrap( Request $request )
    {
        $this->validate($request, [
            'mode' => 'required|string',
            'producerPhone' => 'required|string',
            'collectorID' => 'required|string',
        ]);

        if( !$this->validateRole($request->collectorID) )
        {
            return $this->unauthorisedResponse();
        }

        if(!$this->validateUUID($request->producerPhone) )
        {
            return $this->failedResponse();
        }
        
        $materialstosave = array();
        
        foreach ($request->materials as $mat) {
           $materialobject = (object) [
                'name' => $mat['name'],
                'weight' => $mat['weight'],
                'price' => $mat['price'],
            ];
            array_push($materialstosave, $materialobject);
        }


        $scrap = new collectedScrap();
        $scrap->producerPhone = $request->producerPhone;
        $scrap->collectorID = $request->collectorID;
        $scrap->paymentMethod = $request->mode;
        $scrap->cost = $request->totalCost;
        $scrap->totalTonnage = $request->totalTonnage;
        $scrap->materials = json_encode($materialstosave);
        if(  $producer = User::find('+234'.substr($request->producerPhone, 1)))
        {
            $scrap->address = $producer->userable->requestAddress;
        }else
        {
            $producer = DB::table('users')->where('id', $request->producerPhone)->first();
            $ent = DB::table('enterprises')->where('id', $producer->userable_id)->first();
            $scrap->address = $ent->address;
        }

        $this->calculateTonnage($request->producerPhone, $request->totalTonnage, $request->totalCost, $request->collectorID);

        if($request->mode == 'Wallet')
        {
            $res = $this->creditWallet($request);
            $decoded = json_decode($res);
            if($decoded->success->message)
            {
                $scrap->save();
            }
        }else{
            $scrap->save();
        }

        return $this->successResponse();
    }

    public function calculateTonnage($phone, $totalTonnage, $totalCost, $collectorID)
    {
        if ($producer = User::find($phone)){
           if($tt = $producer->totaltonnage)
           {
                $formattedEarnings = floatval($producer->totalEarnings);
                $formattedCost = floatval($totalCost);
                $producer->totalTonnage = $tt += $totalTonnage;
                $producer->totalEarnings = $formattedEarnings += $formattedCost;
                $producer->save();
           }else{
                $producer->totalTonnage = $totalTonnage;
                $producer->totalEarnings = $totalCost;
                $producer->save();
           }
        }else if($pro = DB::table('users')->where('id', $phone)->first())
        {
            $producer = User::find($pro->phone);
          if($tt = $producer->totaltonnage)
           {
                $formattedEarnings = floatval($producer->totalEarnings);
                $formattedCost = floatval($totalCost);
                $producer->totalTonnage = $tt += $totalTonnage;
                $producer->totalEarnings = $formattedEarnings += $formattedCost;
                $producer->save();
           }else{
                $producer->totalTonnage = $totalTonnage;
                $producer->totalEarnings = $totalCost;
                $producer->save();
           }
        }

        if ($collector = User::find($collectorID)){
           if($tt = $collector->totaltonnage)
           {
                $formattedCost = floatval($totalCost);
                $collector->totalTonnage = $tt += $totalTonnage;
                $collector->save();
           }else{
                $collector->totalTonnage = $totalTonnage;
                $collector->save();
           }
        }
       
    }

    public function validateUUID($phone)
    {
       if($user = User::find($phone))
       {
           return true;
       }else if($user =  DB::table('users')->where('id', $phone)->get()){
           return true;
       }
       return false;
    }

    public function validateRole($id)
    {
        $user = User::find($id);
        return !!$user->userable_type == 'App\Collector';
    }

     public function successResponse()
    {
        return response()->json([
            'data' => 'Collected Scrap Listed Successfully.'
        ], Response::HTTP_OK);
    }

    public function unauthorisedResponse()
    {
        return response()->json([
            'error' => 'You are not authorised.'
        ], Response::HTTP_UNAUTHORIZED);
    }

    public function failedResponse()
    {
        return response()->json([
            'error' => 'There is no user with the supplied ID'
        ], Response::HTTP_NOT_FOUND);
    }

    public function creditWallet(Request $request)
    {
        $phone = '';
        if($user = User::find('+234'.substr($request->producerPhone, 1))){
            $phone = $user->phone;
        }else if($user = DB::table('users')->where('id', $request->producerPhone)->get())
        {
            $phone = $user[0]->phone;
        };
        $unformattedPhone = '0' . explode('+234', $phone)[1];
        $random = Str::random(15);
        $curl = curl_init();
        $publicKey = env('WALLET_PUBLIC_KEY');
        $token = env('WALLET_TOKEN');
        $fields = [
            'data' => [
                    'phone' => $unformattedPhone,
                    'transID' => $random,
                    'narration' => "Scrap Pickup Request",
                    'amount' => $request->totalCost
            ]
        ];
        $fields_string = http_build_query($fields);
        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://apis.dcptap.website/w/public/v1/wallet/credit',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
       CURLOPT_POSTFIELDS => $fields_string,
        CURLOPT_HTTPHEADER => array(
            'token: Bearer '.$token,
            'publicKey: '.$publicKey
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;
    }

    public function getCollectorCollections($phone)
    {
        $collections = DB::table('collected_scraps')->where('collectorID', $phone)->get();
        return response()->json((object)[
            'collections' => $collections
        ], Response::HTTP_OK);
    }

    public function getCollections($phone)
    {
        $collections = DB::table('collected_scraps')->where('producerPhone', $phone)->get();
        if(sizeof($collections) > 0)
        {
            return response()->json((object)[
                'collections' => $collections
            ], Response::HTTP_OK);
        }else
        {
            $producer = User::find($phone);
            $collections = DB::table('collected_scraps')->where('producerPhone', $producer->id)->get();
            return response()->json((object)[
                'collections' => $collections
            ], Response::HTTP_OK);
        }
    }
}
