<?php

namespace App\Http\Controllers;

use App\Collector;
use App\Events\SendLocation;
use Illuminate\Http\Request;

class MapDataController extends Controller
{
    public function ping(Request $request)
    {
        $lat = $request->lat;
        $long = $request->lng;
        $id = $request->id;
        $location = ["lat"=>$lat, "long"=>$long, "id"=>$id];
        event(new SendLocation($location, $id));
        // $coll = Collector::find($id);
        // $coll->current_loc = (object)["lat"=>$lat, "long"=>$long];
        // $coll->save();
        // ->pluck('id', 'current-loc');
        return response()->json(['status'=>'success', 'data'=>$location]);
    }
}
